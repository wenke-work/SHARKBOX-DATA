#!/bin/bash

case ${target_table} in
'ods_xizi_db_meio_wms_area')
    table_columns='code,name,cate,ID,Enabled,CreationDate,Creation_Id,CreationName,ModificationDate,Modification_Id,ModificationName,SortCode,CompanyCode,Company_ID,CompanyFullName,CompanyName,PinYin,PinYinShort,Auditor_ID,AuditorName,AuditStatus,Base_ShopInfoID,ShopName,Workflow_ID,ProjectId,ProjectName,WarehouseID'
;;
esac